﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    private const string connString = @"Data Source = (LocalDB)\MSSQLLocalDB; AttachDbFilename=|DataDirectory|\Database.mdf;";
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void SqlDataSource1_Selecting(object sender, SqlDataSourceSelectingEventArgs e)
    {

    }
    protected void Add(object sender, EventArgs e)
    {
    
        if (Comment.Text != "")
        {
            SqlDataSource1.Insert();
            Comment.Text = "Thank you for your comment.";
        }
        else
        {
            Comment.Text = "Please enter a comment.";
        }
        }
    protected void View(object sender, EventArgs e)
    {
        Session["Comment"] = 0;
        Response.Redirect("PrivateFolder/show.aspx");
    }


}