﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data;

public partial class Show : System.Web.UI.Page {

    protected void Page_Load(object sender, EventArgs e)
    {
        
        DataView dv = (DataView)SqlDataSource1.Select(DataSourceSelectArguments.Empty);
        int temp = dv.Table.Rows.Count;

            if (temp < 1)
            {
                Comment.Text = "No comments.";
            }
            else if ((int)Session["Comment"] == temp)
            {
                Comment.Text = "No more comments.";
                
            }
            else if((int)Session["Comment"] <= temp)
            {
            DataRow row = dv.Table.Rows[(int)Session["Comment"]];
                string x = Convert.ToString(row["Comment"]);
                Comment.Text = x;   
            }
        
        

        
    }

    protected void Delete(object sender, EventArgs e)
    {
        SqlDataSource1.Delete();
        Comment.Text = "No comments.";

    }

    protected void View(object sender, EventArgs e)
    {
        Session["Comment"] = (int)Session["Comment"] + 1;

    }
}