﻿CREATE TABLE [dbo].[Table]
(
	[Id] INT NOT NULL PRIMARY KEY, 
    [Comment] NVARCHAR(MAX) NOT NULL
)
